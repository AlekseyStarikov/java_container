package org.example;

public class Main {
    public static void main(String[] args) {
        Container<Integer> list = new Container<Integer>();
        System.out.println("Длина списка: " + list.length());
        for (int i = 0; i <= 10; i++) {
            list.AddBegin(i);
        }
        System.out.println("1-ый список : " + list.toString());
        Container<Integer> list1 = new Container<Integer>(0);
        for (int i = 1; i <= 10; i++) {
            list1.AddBegin(i);
        }
        System.out.println("2-ый список : " + list1.toString());
        System.out.println("Сравнение списков показало: " + list.equals(list1));
        System.out.println("длина 1-го: " + list.length());
        int a = list.pop(5);
        System.out.println("Длина 1-го после удаления: " + list.length());
        System.out.println("Удаленный элемент: " + a );
        System.out.println("1-ый список после удаления: " + list.toString());
        int elem=-1;
        list.AddLast(elem);
        System.out.println( list.toString());
        list.AddAfterIndex(15,list.length()/2);
        System.out.println( list.toString());
        System.out.println("Индекс"+ elem +"-ки: " + list.Search(-1));

    }
}