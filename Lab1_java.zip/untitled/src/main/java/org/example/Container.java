package org.example;


import java.util.Objects;

/**
 * Класс контейнер
 * @author Алексей Стариков
 **/
public class Container<T> {
    Node head = new Node();

    /**
     * узел списка
     **/
    protected class Node {
        Node next = null;
        T data = null;

        public Node getNext() {
            return next;
        }
        public T getData() {
            return data;
        }

        public void setNext(Node next) {
            this.next = next;
        }
        public void setData(T data) {
            this.data = data;
        }
    }
    /**
     * Конструктор по умолчянию
     **/
    public Container () {
        this.head =null;
    }
    /**
     *  Конструктор с параметром
     **/
    public Container (T data)
    {
        this.head = new Node();
        this.head.setNext(null);
        this.head.setData(data);
    }
    /**
     * Метод для нахождения длины списка
     * @return кол-во элементов сипска
     **/
    public int length()  {
        if(head==null) return 0;
        Node ptr = head;
        int count = 0;
        while ((ptr = ptr.getNext()) != null) {
            count += 1;
        }
        return count;
    }
    /**
     * Метод добавления элементов в начало списка
     **/
    public void AddBegin(T x) {
        if(this.head==null)
        {
            head=new Node();
            head.setNext(null);
            head.setData(x);
        }
        else {
            Node ins = new Node();
            ins.setNext(this.head);
            this.head = ins;
            ins.setData(x);
        }
    }
    /**
     *Метод добавления элементов в конец списка
     **/
    public void AddLast(T x) {
        Node ins = new Node();
        Node ptr = this.head;
        while ( ptr.getNext() != null) {
            ptr =ptr.getNext();
        }
       ptr.setNext(ins);
        ins.setData(x);
    }
    /**
     * Метод добавления элементов в список по заданному индексу
     **/
    public void AddAfterIndex(T x, int i)  {
        Node ptr = this.head;
        int index = -1;
        while (index != i && ptr.getNext().getNext() != null) {
            index += 1;
            ptr = ptr.getNext();
        }
        Node ins = new Node();
        ins.setNext(ptr.getNext());
        ptr.setNext(ins);
        ins.setData(x);
    }

    public Node get(int i) {
        if (this.length() == 0) {
            return null;
        }
        Node ptr = this.head.getNext();
        int index = 0;
        while (index != i && ptr.getNext().getNext() != null) {
            index += 1;
            ptr = ptr.getNext();
        }
        return ptr;
    }
    /**
     * Метод удаления элементов из списка
     * @return data
     **/
    public T pop(int i) {
        if (this.length() == 0) {
            return null;
        }
        Node ptr = this.head.getNext();
        int index = 0;
        while (index != i-1 && ptr.getNext().getNext() != null) {
            index += 1;
            ptr = ptr.getNext();
        }
        Node tmp =ptr.getNext();
        ptr.setNext(tmp.getNext());
        tmp.setNext(null);
        T x = tmp.getData();
        return x;
    }
    /**
     *Метод поиска элементов в списке
     * @return index
     **/
    public int Search(T x) {
        if (this.length() == 0) {
            return 0;
        }
        Node ptr = this.head.getNext();
        int index = 0;
        while (ptr.getData() != x && ptr.getNext() != null) {
            index += 1;
            ptr = ptr.getNext();
        }
        if (ptr.getData() == x) {
            return index;
        }
        else {
            return 0;
        }
    }
    /**
     * Переопределенный метод для перевода значений элементов списка в строку
     **/
    @Override
    public String toString() {
        String str = "Container { ";
        Node ptr = this.head;
        while ((ptr = ptr.getNext()) != null) {
            str += ptr.getData() + " ";
        }
        return str + "}";
    }
    /**
     * Переопределенный метод для сравнения списков
     **/
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Container<?> container = (Container<?>) obj;
        int len = this.length();
        if (container.length() != len) return false;
        Node cur = this.get(0);
        Container<?>.Node cur_container = container.get(0);
        boolean flag = true;
        for (int i = 0; i < len && flag; i++) {
            flag = Objects.equals(cur.getData(), cur_container.getData());
        }
        return flag;
    }

    @Override
    public int hashCode() {
        return Objects.hash(head);
    }
}